package loginandsingup;

public class LoginAndSingUp {

    public static void main(String[] args) {
       
        Login LoginFrameNew = new Login();

    
        LoginFrameNew.setVisible(true);

      
        LoginFrameNew.pack();
        LoginFrameNew.setLocationRelativeTo(null);
    }
}
